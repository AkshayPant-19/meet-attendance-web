# Meet Attendance

A Chrome extension that runs **inside** your online class (Google Meet, Zoom, Microsoft Teams, Cisco Webex, Whereby and more), reads the live participant list, and automatically marks each student from your roster as **Present** or **Absent**.

![Chrome Extension](https://img.shields.io/badge/chrome-extension-v3-brightgreen)
![Platform](https://img.shields.io/badge/platform-Meet%20%7C%20Zoom%20%7C%20Teams%20%7C%20Webex-blue)
![License](https://img.shields.io/badge/license-MIT-green)

> Works in your browser only. No participant data ever leaves your machine — the roster and attendance are stored in `chrome.storage.local`.

> **Read [USAGE.md](USAGE.md) for a step-by-step how-to.** The key point: you must **open the app's Participants/People panel** yourself, or off-screen participants won't be detected.

---

## Install

[![Install](https://img.shields.io/badge/Install-Download%20all%20files-blue?style=for-the-badge&logo=github)](https://github.com/AkshayPant-19/meet-attendance/archive/refs/heads/main.zip)
[![PowerShell installer](https://img.shields.io/badge/PowerShell-One%20click%20install-green?style=for-the-badge&logo=powershell)](https://raw.githubusercontent.com/AkshayPant-19/meet-attendance/main/install.ps1)

**Option A — Install button above.** Downloads a ZIP with every file in this repo. Unzip it anywhere, then load it in Chrome (steps below).

**Option B — One-click PowerShell install (Windows).** Downloads the ZIP, extracts a fresh `meet-attendance` folder into your current directory, and tells you where it is. Either:

- Download and run `install.ps1`, **or**
- Open PowerShell and run:

```powershell
irm https://raw.githubusercontent.com/AkshayPant-19/meet-attendance/main/install.ps1 | iex
```

**Option C — Web installer.** Open your dashboard's **Install** page (`/install`), click **Download extension (.zip)**, unzip it, then load it in Chrome. That page also serves a one-line PowerShell installer (`irm <site>/install.ps1 | iex`).

**Then, in Chrome:**

1. Open `chrome://extensions`.
2. Turn on **Developer mode** (top-right).
3. Click **Load unpacked** and select the folder containing `manifest.json` (e.g. the `meet-attendance` folder the installer created).

> After editing any file, click the **reload** (curved arrow) button on the extension card, then refresh your Meet tab.

## Features

- **Works across web-meeting apps** — Google Meet, Zoom (web), Microsoft Teams, Cisco Webex and Whereby, plus a generic fallback for other in-browser meeting tools.
- **Dark / light theme** — toggle the panel between light and dark; the choice is remembered.
- **In-meeting panel** — a floating widget inside the meeting page; hidden until you summon it with **Ctrl+M**.
- **Live attendance** — present/absent counts update automatically while people join and leave.
- **Reads the whole People panel** — participants beyond the on-screen grid are counted too. Open Meet's **People panel** yourself (see [Usage](#usage)); the extension reads from it and scrolls it so the full list renders.
- **Custom roster** — paste your own student list, or edit the bundled default list.
- **Fuzzy matching** — case- and punctuation-insensitive, so `SHAURYA SINGH` matches Meet's `Sh Aurya Singh`.
- **Draggable panel** — pinned to the bottom-left by default, drag it anywhere so it never covers Meet's toolbar.
- **Built-in debug report** — a one-click report that shows exactly what the scanner sees when something isn't detected.
- **Timestamps** — records each student's **join** and **leave** time, plus an attendance log every **5 minutes** (with who left/joined and whether attendance stayed consistent), shown in the panel and included in the CSV export.
- **CSV export** — download `meeting_attendance.csv` at the end of class.
- **Session reset** — start a clean attendance record for the next meeting.
- **Sync to the web dashboard (optional)** — set a server URL + API token in the popup, then press **Sync to server** to push the session to your account. With auto-sync on (default) it pushes **every 5 minutes** and on leave, always updating the **same** session.

## Table of Contents

- [Install](#install)
- [Usage](#usage)
- [Customizing the student list](#customizing-the-student-list)
- [How it works](#how-it-works)
- [Project structure](#project-structure)
- [Troubleshooting](#troubleshooting)
- [Privacy](#privacy)
- [License](#license)

---

## Requirements

- Google Chrome (or a Chromium-based browser such as Edge or Brave)
- A supported web-meeting app: Google Meet, Zoom (web client), Microsoft Teams (web), Cisco Webex (web) or Whereby
- No other dependencies — the extension is plain JavaScript with zero libraries

---

## Usage

> Full walkthrough in [USAGE.md](USAGE.md). The steps below are for Google Meet; the flow is the same on Zoom, Teams and Webex — just open **that app's Participants panel** instead of Meet's People panel.

1. (Optional) Edit the student list in `default-students.js` or via the extension popup.
2. Open a meeting (Google Meet, Zoom web, Microsoft Teams, Webex or Whereby) — via a link, the calendar, or a fresh tab.
3. Press **Ctrl+M** to open the **Attendance** panel (bottom-left by default). Press **Ctrl+M** again to hide it. Drag it by its title bar if you need it elsewhere. Use the **Dark / Light** button in the header to switch theme.
4. Check the student list is filled in (it is pre-filled from `default-students.js`). Edit if needed and click **Save list**.
> **Important:** open the app's **Participants/People panel** yourself before/during monitoring (in Meet: the **People** icon, or **More options → People** if the toolbar is collapsed) and keep it open. The scanner reads participant names from that panel — off-grid students are only listed there. The extension will try to re-open it if it gets closed, but for reliable attendance open it manually.

5. Click **Start monitoring**. The extension verifies the **People panel** is open every 5s (via the toolbar button, the **More options → People** menu, or the **"+N" chip**), then **scrolls the panel step-by-step**, scanning right after every step, so the entire roster (including people beyond the video grid) is read and marked. Present / Absent counts update live, and each student's **join time** is recorded on first detection.
6. Monitoring takes an attendance **snapshot every 5 minutes**, noting who joined, who left, and whether the present list was **consistent** with the previous snapshot (visible in the panel's *Session log*). Press **Stop** to finalize each student's **leave time**.
7. At the end of the meeting click **Export CSV** — it downloads the roster with **Join / Leave / Duration** columns, followed by the 5-minute log.

### Controls

| Control | Action |
| --- | --- |
| `Ctrl+M` | Show / hide the panel |
| Save list | Store the current roster for future meetings |
| Start monitoring | Open the People panel and begin scanning participants continuously |
| Stop | Pause scanning |
| Export CSV | Download `meeting_attendance.csv` |
| Sync to server | Send the session to your web dashboard (needs a server URL + API token) |
| Reset session | Clear attendance + timestamps for a new meeting |
| Debug | Copy a diagnostic report to the clipboard / console |

---

## Customizing the student list

You can set the default roster in `default-students.js` — one name per line:

```js
window.MEET_ATTENDANCE_DEFAULT_STUDENTS = [
  "SHAURYA SINGH",
  "TANISHK BHATT",
  // ...
];
```

Or edit it at runtime from the extension popup (toolbar icon) or the in-meeting panel. The in-meeting panel always shows the saved roster, so you can paste a fresh list for each class and click **Save list**.

### Matching rules

- Names are compared **case-insensitively** and punctuation is ignored.
- Spaces are ignored too (so `Sh Aurya Singh` matches `SHAURYA SINGH`).
- Pronouns/status words are stripped (`(You)`, `(He/Him)`, `presenting`).
- **The surname is not required.** A student counts if their unique **first
  name** is detected — so `Tanishk`, `Tanishk B.` or `Tanishk Bhattcharya`
  all match `TANISHK BHATT`.
- **Ambiguity guard:** if a first name appears on the roster more than once
  (e.g. two Shauryas), first-name-only matching is refused and a full-name
  match is required — so a bare `SHAURYA` never falsely marks either.
- When a tile's text contains a multi-word student name intact, that student
  is recorded (handles `PARAS BHATT muted`-style tiles and tooltips such as
  `Pin Akshay Pant to your main screen`).
- Names inside the open **People panel** are read straight from its rows
  (`role="listitem"`), so off-grid participants are counted even when their
  tiles never appear in the video layout.

## Automated tests

The matching and extraction logic lives in `core.js` and is covered by a deep
test suite that runs in plain Node (no dependencies):

```bash
node tests/run.js
```

It verifies format tolerance, false-positive protection (shared surnames,
first-name ambiguity, typos), present/absent/unknown categorization,
extraction from simulated Meet DOMs (including People-panel drawer rows and
tooltip-garbage behaviour), multi-platform detection and generic extraction
(Zoom / Teams / Webex / generic), a short-text guard against aggregator
containers, and performance at high saturation (200k matches, 60-participant
scans). Run it after any change to `core.js`. Current: 35 checks / 0 failures.

---

## How it works

`content.js` injects a hidden panel into the Meet page. While monitoring:

1. The extension verifies Meet's **People panel** is open (toolbar button, **More options → People** when the toolbar is collapsed, or the **"+N" chip** as a last resort) and re-checks every 5s — an 8s cooldown stops a detection miss from toggling the panel closed. **You should open the panel yourself first**; it's the most reliable way to guarantee off-grid participants are listed.
2. A paced **scroll + record loop** runs every 650ms: it scrolls the drawer one
   step down (only when the panel is actually open — it never scrolls the video
   grid), then scans, so row rendering and detection stay in sync. Reaching the
   bottom resets to the top to catch anyone who joined late.
3. A **filtered `MutationObserver`** rescans only when a change actually touches
   participant rows or the drawer — chat/transcript/animation churn doesn't
   trigger full-page scans.
4. Participant names are extracted from three sources:
   - participant tiles (`[data-participant-id]`), using known name containers,
     `aria-label`, or the tile text as fallback;
   - the People-panel drawer rows (`role="listitem"`), tolerating trailing
     suffixes like `(You)` or mic-state labels;
   - a broad scan that flags any page element whose short text exactly equals a
     roster name.
6. Each detected name is fuzzy-matched against the roster and marked Present.
5. Results render in the panel and are persisted to `chrome.storage.local`.

---

## Project structure

```
meet attendance/
├── manifest.json          # Chrome extension config (Manifest V3) + supported hosts
├── default-students.js    # Default roster (edit this)
├── core.js                # Shared matching/extraction logic + platform registry (also used by tests)
├── content.js             # Injects into the meeting page — scans participants, shows panel
├── popup.html             # Toolbar popup UI
├── popup.js               # Popup logic for editing/saving the roster
├── install.ps1            # One-click Windows installer (downloads all files into a folder)
├── tests/run.js           # Automated deep test suite (node tests/run.js)
├── USAGE.md               # Step-by-step how-to-use guide
├── CHANGELOG.md           # Version history / changelog
└── README.md              # This file
```

---

## Troubleshooting

**The panel doesn't appear when I press Ctrl+M**
1. Reload the extension card on `chrome://extensions`.
2. Open the Meet tab **fresh** (or press F5) — content scripts don't inject into tabs that were open before the extension loaded.
3. Press F12 → Console and confirm you see `[Meet Attendance] content script loaded on ...`. If you don't, the extension isn't injected.

**Some participants aren't detected**
- One of the biggest offenders: **off-layout participants**. When a meeting has more people than fit on the video grid, Meet only keeps everyone's names in the page while the **People panel is open** — so **open the People panel yourself** (People icon, or **More options → People**) and keep it open. The extension tries to re-open it if it closes, but manual is most reliable.
- If names are still missing, click **Debug** in the panel and paste the report — it shows whether the panel was found/open, how many tiles exist, and exactly what was detected.
- Google Meet frequently changes its internal DOM. If known participants go missing anyway, update the `NAME_SELECTORS` array at the top of `core.js`.
- Participants who joined late only appear once their row renders — the scanner keeps scrolling the panel, so give it a few seconds.

**`Extension context invalidated` in the console**
This appears in a Meet tab that was open while the extension was reloaded. Refresh the Meet tab.

**The times in the CSV look wrong**
Join/leave times are only as accurate as detection: someone who joins late or appears off-grid is timed from when they were first actually read. If you forgot to press **Stop**, everyone who was present when the tab closed keeps their last-seen time as "Leave". Timestamps are also reset automatically when you **Start monitoring** in a *different* meeting.

**Attendance list looks wrong for a new meeting**
Click **Reset session** before the next meeting to clear the previous record (timestamps and log included).

---

## Privacy

- Everything runs locally in your browser by default.
- The roster and attendance live in `chrome.storage.local`. They are only ever
  **uploaded if you opt in** by setting a server URL + API token and pressing
  **Sync to server** — nothing is sent otherwise.
- The extension reads the meeting page's participant list; with sync enabled it
  sends only the attendance data (names, join/leave times) to **your own**
  dashboard.

---

## Contributing

Found a bug or have an idea? Open an issue or a pull request. Please update the `NAME_SELECTORS` and matching logic notes if you improve participant extraction — that's the part most likely to break as Meet changes. After touching `core.js`, run `node tests/run.js`.

---

## License

[MIT](LICENSE)
